import React from "react";
import SearchRooms from "./SearchRooms";

const Rooms = () => {
  return (
    <div>
      <SearchRooms />
    </div>
  );
};

export default Rooms;
